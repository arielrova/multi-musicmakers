import firebase from 'firebase/app';
import 'firebase/database';

var config = {
  apiKey: "AIzaSyBWWN3kzKmp_aCvq_9Ke9NAS5uGKKupV3c",
  authDomain: "multi-musicmakers.firebaseapp.com",
  databaseURL: "https://multi-musicmakers.firebaseio.com",
  projectId: "multi-musicmakers",
  storageBucket: "multi-musicmakers.appspot.com",
  messagingSenderId: "565100187566"
};

firebase.initializeApp(config);

const db = firebase.database();

export {
    db
};